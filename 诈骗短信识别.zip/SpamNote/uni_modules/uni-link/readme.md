

## Link 链接
> **组件名：uni-link**
> 代码块： `uLink`


uni-link是一个外部网页超链接组件，在小程序内复制url，在app内打开外部浏览器，在h5端打开新网页。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-link)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 