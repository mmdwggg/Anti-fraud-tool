module.exports = {
  getFrvCertifyId: require('./get-certify-id'),
  getFrvAuthResult: require('./get-auth-result')
}
